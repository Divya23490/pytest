import utilities.custom_logger as cl
import logging
from base.basepage import BasePage


class LoggedInPage(BasePage):

    log = cl.customLogger(logging.DEBUG)

    def __init__(self, driver):
        super().__init__(driver)
        self.driver = driver
        self.searchPage_locators=self.pageLocators('SearchPage')
        self.loggedInPage_locators = self.pageLocators('Search_Fields')

    @property
    def isAt(self):
        input_search = self.getElementList(*self.locator(self.loggedInPage_locators, 'input_search'))
        if len(input_search) > 0:
            return True
        return False

    def search_text(self, input_search):
        self.elementClick(*self.locator(self.searchPage_locators, 'search'))
        self.sendKeys(input_search, *self.locator(self.searchPage_locators, 'search'))
        self.elementClick(*self.locator(self.loggedInPage_locators, 'input_search'))
        self.elementClick(*self.locator(self.loggedInPage_locators, 'first_value'))
        self.elementClick(*self.locator(self.loggedInPage_locators, 'logo_image'))
