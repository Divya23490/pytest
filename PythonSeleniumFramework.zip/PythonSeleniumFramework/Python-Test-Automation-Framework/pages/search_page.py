import utilities.custom_logger as cl
import logging
from base.basepage import BasePage


class SearchPage(BasePage):

    log = cl.customLogger(logging.DEBUG)

    def __init__(self, driver):
        super().__init__(driver)
        self.driver = driver
        self.searchPage_locators = self.pageLocators('SearchPage')

    def isAt(self):
        header_login = self.getElementList(*self.locator(self.searchPage_locators, 'header_title'))
        if len(header_login) > 0:
            return True
        return False

    def search(self, input_value):
        self.elementClick(*self.locator(self.searchPage_locators, 'search'))
        self.sendKeys(input_value, *self.locator(self.searchPage_locators, 'search'))
        self.elementClick(*self.locator(self.searchPage_locators, 'search_button'))
        self.elementClick(*self.locator(self.searchPage_locators, 'first_result'))
        self.elementClick(*self.locator(self.searchPage_locators, 'logo_img'))
