import utilities.read_json as RJ
import os


def testData(attribute):
    testDataPath = "C:/Users/divkhurana/Desktop/PythonSeleniumFramework/Python-Test-Automation-Framework/test_data/test_data.json"
    print(testDataPath)
    testDataJsonFile = RJ.readJson(testDataPath)

    return testDataJsonFile[attribute]