from utilities.teststatus import TestStatus
from navigation.homeNavigation import HomeNavigation
from pages.search_page import SearchPage
from pages.loggedin_page import LoggedInPage
import test_data.testData as td
import unittest
import pytest
import sys
import allure
from pytest_testrail.plugin import pytestrail

sys.path.insert(0, '../..')


@pytest.mark.usefixtures("oneTimeSetUp", "setUp")
class LoginTest(unittest.TestCase):

    @pytest.fixture(autouse=True)
    def classSetup(self):
        self.homeNavigation = HomeNavigation(self.driver)
        self.searchPage = SearchPage(self.driver)
        self.loggedInPage = LoggedInPage(self.driver)
        self.ts = TestStatus(self.driver)

    # @pytest.mark.run(order=1)
    @allure.story('epic_1') # epic/story of the test case
    @allure.severity(allure.severity_level.MINOR) # severity of the test case
    # @pytestrail.case('C48') # test case if on TestRail
    def test_login_successfully(self):
        with allure.step('Navigate to Google page'):
            self.ts.markFinal(self.searchPage.isAt, "navigation to Google home page failed")

        with allure.step('Search'):
            self.searchPage.search(input_value=td.testData("input_value"))
            self.ts.markFinal(self.searchPage.isAt, "Search failed")

